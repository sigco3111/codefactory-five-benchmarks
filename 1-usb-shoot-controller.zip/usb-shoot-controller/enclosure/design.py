"""CadQuery 2.6.1 parametric prototype. Run from project root. Units: mm.
Edit P, regenerate, and inspect clearance_report.json before using changed parts.
"""
import json
from pathlib import Path
import cadquery as cq
OUT=Path(__file__).resolve().parent
P=dict(width=120.,depth=85.,height=42.,wall=2.,base=2.,lid=2.,
       pico_x=2.6,pico_y=12.,pico_z=8.,pico_pcb_t=1.,
       oled_x=57.,oled_y=15.,oled_w=52.,oled_d=25.,oled_pcb_t=1.6,
       oled_header_depth=11.4,board_clearance=.3,support_edge=.8,
       button_centers=[[30.,62.],[70.,62.]],button_hole=16.4,
       led_center=[100.,62.],led_hole=5.3,screw_clearance=2.4,pilot=1.6,screw_edge=7.)
W,D,H=P['width'],P['depth'],P['height']
T,B,L=P['wall'],P['base'],P['lid']
px,py,pz=P['pico_x'],P['pico_y'],P['pico_z']
ox,oy,ow,od=P['oled_x'],P['oled_y'],P['oled_w'],P['oled_d']
ot=P['oled_pcb_t'];oz=H-L-ot;c=P['board_clearance'];support=P['support_edge']
assert W>80 and D>60 and H>34 and T>=1.6 and c>=0

def box(x,y,z,dx,dy,dz):
 return cq.Workplane('XY').box(dx,dy,dz,centered=False).translate((x,y,z))
def cyl(x,y,z,r,h):
 return cq.Workplane('XY').circle(r).extrude(h).translate((x,y,z))
base=box(0,0,0,W,D,H-L).cut(box(T,T,B,W-2*T,D-2*T,H))
e=P['screw_edge'];case_screws=[(e,e),(W-e,e),(e,D-e),(W-e,D-e)]
for x,y in case_screws:
 base=base.union(cyl(x,y,B,3.5,H-L-B)).cut(cyl(x,y,H-L-9,P['pilot']/2,10))
# Official Pico holes, USB end at local longitudinal x=0.
pico_screws=[(px+x,py+y) for x in [2.,48.6] for y in [4.8,16.2]]
for x,y in pico_screws:
 base=base.union(cyl(x,y,B,2,pz-B)).cut(cyl(x,y,B+1,P['pilot']/2,pz-B))
base=base.cut(box(-1,py+3.5,pz-1,T+3,14,10))
lid=box(0,0,H-L,W,D,L)
for x,y in case_screws:lid=lid.cut(cyl(x,y,H-L-1,P['screw_clearance']/2,L+2))
for x,y in P['button_centers']:lid=lid.cut(cyl(x,y,H-L-1,P['button_hole']/2,L+2))
lx,ly=P['led_center'];lid=lid.cut(cyl(lx,ly,H-L-1,P['led_hole']/2,L+2))
lid=lid.cut(box(ox-c,oy-c,H-L-1,ow+2*c,od+2*c,L+2))
frame=box(ox-c-2,oy-c-2,oz-2,ow+2*c+4,od+2*c+4,H-L-oz+2)
frame=frame.cut(box(ox-c,oy-c,oz,ow+2*c,od+2*c,ot+L+1))
frame=frame.cut(box(ox+support,oy+support,oz-3,ow-2*support,od-2*support,4))
lid=lid.union(frame)
clip_centers=[(ox-c-4,oy+od/2),(ox+ow+c+4,oy+od/2)]
for x,y in clip_centers:
 lid=lid.union(cyl(x,y,oz-2,2.7,H-L-oz+2)).cut(cyl(x,y,oz-2.4,P['pilot']/2,H-oz+2))
# Local clip broad outer face z=2. Tip reaches the PCB top H-L when installed at H.
clip=box(-3,-3,0,8,6,2).union(box(4,-3,-L,1,6,L)).cut(cyl(0,0,-L-1,P['screw_clearance']/2,L+4))
parts={'base':base,'lid':lid,'oled_clip':clip}
components={
 'pico':box(px,py,pz,51,21,P['pico_pcb_t']),
 'pico_parts':box(px+7.4,py+2,pz+1,40,17,4),
 'pico_usb':box(px-1.3,py+6.5,pz+1,7,8,3.8),
 'oled':box(ox,oy,oz,ow,od,ot),
 'oled_header_keepout':box(ox+1,oy+1,oz-P['oled_header_depth'],ow-2,od-2,P['oled_header_depth']),
 'led':cyl(lx,ly,H-L-8,2.5,7).union(cyl(lx,ly,H-L-1,2.95,1)),
 'led_lens':cyl(lx,ly,H-L,2.5,7.6)}
for name,(x,y) in zip(['button_rec','button_scene'],P['button_centers']):
 components[name]=cyl(x,y,H-L-30,9.2,30)
 components[name+'_cap']=cyl(x,y,H,9.03,1).union(cyl(x,y,H+1,6.5,4))
components['clip_left']=clip.translate((*clip_centers[0],H))
components['clip_right']=clip.rotate((0,0,0),(0,0,1),180).translate((*clip_centers[1],H))
checks={}
for name,obj in components.items():
 for target,shape in [('base',base),('lid',lid)]:
  checks[f'{name}_{target}_collision_mm3']=round(obj.intersect(shape).val().Volume(),6)
keys=list(components)
for i,a in enumerate(keys):
 for b in keys[i+1:]:
  v=components[a].intersect(components[b]).val().Volume()
  if v>1e-6:checks[a+'__'+b+'_overlap_mm3']=round(v,6)
checks['solids']={k:len(v.solids().vals()) for k,v in parts.items()}
checks['valid']={k:v.val().isValid() for k,v in parts.items()}
checks['volumes_mm3']={k:round(v.val().Volume(),2) for k,v in parts.items()}
(OUT/'parameters.json').write_text(json.dumps(P,indent=2))
(OUT/'clearance_report.json').write_text(json.dumps(checks,indent=2))
for name,obj in parts.items():
 cq.exporters.export(obj,str(OUT/(name+'.stl')),tolerance=.05,angularTolerance=.1)
 cq.exporters.export(obj,str(OUT/(name+'.step')))
assembly=cq.Assembly()
for name,obj in {k:v for k,v in parts.items() if k!='oled_clip'}.items():assembly.add(obj,name=name)
for name,obj in components.items():assembly.add(obj,name=name)
assembly.save(str(OUT/'assembly.step'))
mesh=[]
for name,obj in {**parts,**components}.items():
 if name=='oled_clip':continue
 verts,faces=obj.val().tessellate(.3)
 mesh.append(dict(name=name,vertices=[[v.x,v.y,v.z] for v in verts],faces=faces))
(OUT.parent/'preview'/'geometry.json').write_text(json.dumps(mesh,separators=(',',':')))
print(json.dumps(checks,indent=2))
assert all(checks['valid'].values()) and all(v==1 for v in checks['solids'].values())
assert all(v==0 for k,v in checks.items() if k.endswith(('collision_mm3','overlap_mm3')))
