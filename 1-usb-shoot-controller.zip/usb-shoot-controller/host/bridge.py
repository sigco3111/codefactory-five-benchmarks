"""USB CDC -> OBS WebSocket v5. Local loopback only. No credentials on disk."""
import argparse
import getpass
import asyncio
import base64
import hashlib
import json
import logging
import os
import time
from urllib.parse import urlparse

import serial
from websockets.asyncio.client import connect

LOG = logging.getLogger('shoot')


def authentication(password, salt, challenge):
    secret = base64.b64encode(hashlib.sha256((password + salt).encode()).digest()).decode()
    return base64.b64encode(hashlib.sha256((secret + challenge).encode()).digest()).decode()


class OBS:
    def __init__(self, url, password):
        self.url, self.password = url, password
        self.ws = None
        self.pending = {}
        self.counter = 0
        self.generation = 0
        self.ready = False
        self.reader = None

    async def open(self):
        self.ws = await connect(self.url, open_timeout=3, max_size=1024*1024)
        hello = json.loads(await asyncio.wait_for(self.ws.recv(), 3))
        if hello.get('op') != 0:
            raise RuntimeError('Expected OBS Hello')
        data = {'rpcVersion': 1, 'eventSubscriptions': 4 | 64}
        auth = hello['d'].get('authentication')
        if auth:
            if not self.password:
                raise RuntimeError('OBS_PASSWORD environment variable required')
            data['authentication'] = authentication(self.password, auth['salt'], auth['challenge'])
        await self.ws.send(json.dumps({'op': 1, 'd': data}))
        identified = json.loads(await asyncio.wait_for(self.ws.recv(), 3))
        if identified.get('op') != 2:
            raise RuntimeError('OBS authentication failed')
        self.ready = True
        self.reader = asyncio.create_task(self.receive())

    async def receive(self):
        try:
            async for raw in self.ws:
                msg = json.loads(raw)
                if msg.get('op') == 7:
                    d = msg['d']
                    future = self.pending.get(d.get('requestId'))
                    if future and not future.done():
                        future.set_result(d)
                elif msg.get('op') == 5:
                    self.generation += 1
        finally:
            self.ready = False
            for f in self.pending.values():
                if not f.done():
                    f.set_exception(ConnectionError('OBS disconnected'))

    async def request(self, kind, data=None):
        if not self.ready:
            raise ConnectionError('OBS not identified')
        self.counter += 1
        rid = str(self.counter)
        f = asyncio.get_running_loop().create_future()
        self.pending[rid] = f
        try:
            await self.ws.send(json.dumps({'op': 6, 'd': {
                'requestType': kind, 'requestId': rid, 'requestData': data or {}}}))
            result = await asyncio.wait_for(f, 1.2)
            if not result['requestStatus']['result']:
                raise RuntimeError('OBS rejected ' + kind)
            return result.get('responseData', {})
        finally:
            self.pending.pop(rid, None)

    async def close(self):
        self.ready = False
        if self.ws:
            await self.ws.close()
        if self.reader:
            try:
                await self.reader
            except Exception:
                pass


class Controller:
    def __init__(self, obs, scenes):
        self.obs, self.scenes = obs, scenes
        self.seen = {}
        self.last_command = -100
        self.lock = asyncio.Lock()

    async def snapshot(self):
        async with self.lock:
            generation = self.obs.generation
            rec = await self.obs.request('GetRecordStatus')
            # Do not advertise a snapshot crossed by an OBS event.
            if generation != self.obs.generation:
                raise RuntimeError('State changed during snapshot')
            active, paused = bool(rec['outputActive']), bool(rec['outputPaused'])
            seconds = max(0, min(3599999, int(rec['outputDuration']) // 1000))
            return f'S 1 1 {int(active)} {int(paused and active)} {seconds}\n'

    async def event(self, line):
        fields = line.split()
        if len(fields) != 4 or fields[0] != 'E' or fields[3] not in ('R', 'N'):
            return False
        try:
            boot = int(fields[1], 16)
            seq = int(fields[2])
            if not 0 <= boot <= 0xffffffff or not 1 <= seq <= 0xffffffff:
                return False
        except ValueError:
            return False
        # Consume event even on error. Never replay an ambiguous recording action.
        if seq <= self.seen.get(boot, 0):
            return False
        self.seen[boot] = seq
        if len(self.seen) > 16:
            self.seen.pop(next(iter(self.seen)))
        now = time.monotonic()
        if now - self.last_command < .5:
            return False
        self.last_command = now
        async with self.lock:
            if fields[3] == 'R':
                state = await self.obs.request('GetRecordStatus')
                await self.obs.request('StopRecord' if state['outputActive'] else 'StartRecord')
            else:
                state = await self.obs.request('GetSceneList')
                names = [x['sceneName'] for x in state['scenes']]
                available = self.scenes or names
                if not available or any(x not in names for x in available):
                    raise RuntimeError('Configured scenes missing in OBS')
                current = state.get('currentProgramSceneName')
                target = available[(available.index(current)+1) % len(available)] if current in available else available[0]
                await self.obs.request('SetCurrentProgramScene', {'sceneName': target})
        return True


async def run(args):
    obs = None
    port = None
    controller = None
    # Entire connection pair is restarted after failures. Serial queued input is discarded.
    while True:
        try:
            obs = OBS(args.obs_url, os.environ.get('OBS_PASSWORD', ''))
            await obs.open()
            port = serial.Serial(args.port, 115200, timeout=.1, write_timeout=.3)
            port.dtr = True
            port.reset_input_buffer()
            controller = Controller(obs, args.scene)
            next_poll = 0
            while obs.ready:
                if time.monotonic() >= next_poll:
                    state = await controller.snapshot()
                    await asyncio.to_thread(port.write, state.encode('ascii'))
                    next_poll = time.monotonic() + .4
                raw = await asyncio.to_thread(port.read_until, b'\n', 128)
                if not raw:
                    continue
                if len(raw) >= 128 or not raw.endswith(b'\n'):
                    raise RuntimeError('Invalid or oversized USB frame')
                if raw.startswith(b'E '):
                    # Remove READY during an operation; re-sync before accepting another.
                    await asyncio.to_thread(port.write, b'S 1 0 0 0 0\n')
                    await controller.event(raw.decode('ascii'))
                    next_poll = 0
            raise ConnectionError('OBS link lost')
        except (OSError, RuntimeError, ValueError, TimeoutError, ConnectionError) as e:
            LOG.warning('Connection unavailable: %s', type(e).__name__)
        except Exception as e:
            LOG.warning('Reconnect after %s', type(e).__name__)
        finally:
            if port:
                try:
                    port.write(b'S 1 0 0 0 0\n')
                    port.close()
                except (OSError, serial.SerialException):
                    pass
                port = None
            if obs:
                await obs.close()
        await asyncio.sleep(2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ask-password', action='store_true', help='Read OBS password privately in this terminal; never save it')
    parser.add_argument('--port', required=True, help='Explicit Pico serial port; never auto-select another device')
    parser.add_argument('--obs-url', default='ws://127.0.0.1:4455')
    parser.add_argument('--scene', action='append', default=[], help='Allowed scene cycle, repeat in order')
    args = parser.parse_args()
    u = urlparse(args.obs_url)
    if u.scheme != 'ws' or u.hostname not in ('127.0.0.1', 'localhost', '::1') or u.username or u.password:
        parser.error('Only local loopback ws:// OBS endpoints are allowed')
    if args.ask_password:
        os.environ['OBS_PASSWORD'] = getpass.getpass('OBS WebSocket password: ')
    logging.basicConfig(level=logging.INFO)
    try:
        asyncio.run(run(args))
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
