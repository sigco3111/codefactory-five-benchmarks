# 구조 / 프로토콜

```
NO 패널 버튼 2개 → Pico RP2040 USB CDC ↔ 로컬 Python bridge ↔ OBS WebSocket v5
                         ↓                                    ↑
                 SH1107 OLED + 적색 LED         실제 GetRecordStatus / 장면 목록
```

## 상태와 재연결
USB는 CDC ACM 직렬 장치이며 키보드 단축키를 흉내 내지 않는다. OBS 28+에 포함된 WebSocket v5 서버의 RPC v1을 사용한다. 호스트는 127.0.0.1의 OBS에만 접속하며 비밀번호는 `OBS_PASSWORD` 환경변수로 받는다. challenge/salt SHA-256 인증을 구현했다. 인증정보를 로그에 쓰지 않는다.

브리지는 OBS 식별 후 직렬 포트를 연다. 400 ms 간격으로 GetRecordStatus를 조회하고, USB로 확인된 상태를 보낸다. RecordStateChanged 등 녹화/장면 이벤트도 구독한다. 조회와 동시에 이벤트가 발생하면 해당 스냅샷은 버리고 연결을 다시 잡는다. OBS 이벤트가 누락돼도 주기 조회로 복구한다. 경과 시간은 outputDuration(ms)을 초 단위로 내림하며 장치에서 임의 증가시키지 않는다. OBS와 화면 사이에는 통신·조회 지연이 있다. 상태 갱신이 2초 이상 끊기면 장치가 독립적으로 상태 미확인으로 바뀐다.

녹화 버튼 명령 직전 GetRecordStatus를 다시 조회하고 StartRecord / StopRecord 중 하나만 전송한다. ToggleRecord를 사용하지 않으며, 응답이 소실된 명령을 재시도하지 않는다. 이후 새 조회로 실제 결과를 확인한다. 실패 뒤 사용자가 다시 누르는 동작만 새 의도다. 외부 조작과 조회 사이의 경합은 완전히 막을 수 없으므로 오류는 성공으로 표시하지 않는다.

장면 순환은 `GetSceneList`의 현재 program 장면을 기준으로 한다. Studio Mode의 preview만 바꾸는 기능이 아니다. `--scene` 목록이 있으면 모두 실제 존재하는지 확인하며 없는 이름을 추측하지 않는다. 인자가 없으면 OBS가 반환한 순서를 쓴다.

## ASCII USB 프로토콜 v1
115200 baud 설정(USB CDC에서 물리 UART 속도는 아님), LF 종료, ASCII. 펌웨어 수신 최대 99자, 호스트 수신 최대 127바이트.

| 방향 | 형식 | 의미 |
|---|---|---|
| 장치→호스트 | `H 1 <boot_hex>` | 1초마다 식별용 heartbeat |
| 장치→호스트 | `E <boot_hex> <seq> R` | REC 한 번 눌림 |
| 장치→호스트 | `E <boot_hex> <seq> N` | SCENE 한 번 눌림 |
| 호스트→장치 | `S 1 <online> <active> <paused> <seconds>` | 확인 상태. bool은 0/1, 시간은 0..3599999 |

예: `S 1 1 1 0 125`는 연결됨/녹화중/일시정지아님/125초. `S 1 0 0 0 0`은 미확인이다. 장치는 올바른 S만 watchdog 갱신에 사용한다. 행 초과·불완전 행·잘못된 bool·음수 시간은 무시한다.

물리 디바운스는 안정 30 ms, 길게 누름은 1회, 부팅 때 이미 누른 버튼은 다시 떼기 전 발동하지 않는다. 전체 버튼 쿨다운은 500 ms다. 호스트도 500 ms 제한과 boot/seq 단조 증가 검사를 한다. 호스트는 최근 16개 boot 식별자의 마지막 seq를 보관한다. boot 토큰은 보안용이 아니다. 재연결 시 직렬 입력 큐를 비우고 과거 입력을 재생하지 않는다. 작업 중 먼저 offline을 보내며, 새 스냅샷 이후 다시 준비 상태가 된다.

## 라이브러리 / 빌드
- Pico SDK 2.1.1 + 해당 SDK가 고정한 TinyUSB submodule. pico_stdlib / pico_stdio_usb / hardware_spi / pico_rand.
- OLED는 외부 라이브러리 없이 포함한 SH1107 드라이버를 사용. Waveshare 공식 SPI 예제의 초기화·행 주소 매핑을 따름. SPI1 2 MHz mode 0. Wiki 서술은 mode 3라고 하지만 공식 실행 예제는 mode 0이어서 예제를 채택했다. 실제 패널에서 확인할 항목이다.
- 호스트 Python 3.10+, pyserial 3.5, websockets 15.0.1. 테스트 서버도 동일 WebSocket 라이브러리를 사용하지만 OBS 프로토콜의 다른 끝을 독립적으로 흉내 낸다.
- CAD는 CadQuery 2.6.1. preview geometry.json은 CAD 삼각형을 직접 내보낸 것이라 케이스 형상이 따로 그려진 모형이 아니다.
