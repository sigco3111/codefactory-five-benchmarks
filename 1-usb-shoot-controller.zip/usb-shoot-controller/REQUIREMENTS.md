# 요구사항과 범위

## 제품
- USB 데이터 케이블 하나로 연결하는 120 × 85 × 42 mm 데스크 촬영 컨트롤러 프로토타입.
- REC 버튼은 OBS 실제 상태를 먼저 조회하고 StartRecord 또는 StopRecord를 보낸다. SCENE 버튼은 실제 장면 목록 또는 사용자가 지정한 허용 목록을 순환한다.
- 빨간 LED는 마지막으로 확인한 OBS 녹화 활성 상태만 표시한다. 일시정지 중에도 녹화 세션은 활성 상태이므로 켜진다. OLED는 PAUSED를 별도 표시한다.
- OLED는 OBS outputDuration에서 받은 경과 시간과 READY / RECORDING / PAUSED / LINK LOST를 표시한다. 버튼만으로 녹화 표시를 켜지 않는다.
- 호스트 중단·USB/OBS 통신 상실 시 최대 2초 내 LED를 끄고 LINK LOST를 표시한다. 이때 LED 꺼짐은 녹화 중지가 아니라 상태 미확인이다.
- 무선, 배터리, 상용전원 회로 없음. 계정 정보·OBS 비밀번호 파일 저장 없음.

## 고정 부품
원형 Raspberry Pi Pico RP2040 SC0915, 헤더 미장착 / Waveshare Pico-OLED-1.3 SH1107 기본 SPI / Adafruit 1445 적색 비조명 NO 패널 버튼 2개 / Kingbright WP7113ID 적색 5 mm LED / 330 Ω 저항.
Pico W, Pico 2, SSD1306 OLED, I2C 변경품으로 대체하지 않는다. OLED는 Pico 위에 꽂지 않고 분리 배선한다. 모듈의 사용자 버튼 GP15·GP17은 사용하지 않는다.

## 합격 기준
펌웨어 ARM 빌드, 브리지 프로토콜 자동시험, CAD 솔리드 검사, STL/STEP 생성, 실제 설계와 공유하는 로컬 미리보기까지 디지털 검증한다. 실물의 전류·스위치 작동·OLED 방향·USB 플러그·열·인쇄 공차·OBS 실제 버전은 인수 시험 후에만 합격 판정한다.

## 제외
전용 PCB, 제조 완료 판정, 인증 적합 판정, 부품 구매, 발주, 유료 생성, 배포, 저장소 생성·커밋은 수행하지 않는다. 창작자 도구이며 AI 추론 기능은 추가하지 않았다. 선택 모델명/effort의 내부 정보를 기록하지 않는다.
