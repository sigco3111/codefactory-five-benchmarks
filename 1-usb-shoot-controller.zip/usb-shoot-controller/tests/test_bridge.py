import asyncio
import base64
import hashlib
import json
import sys
import unittest
import queue
import os
import time
from types import SimpleNamespace
from unittest.mock import patch
import serial
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'host'))
from bridge import OBS, Controller, authentication, run
from websockets.asyncio.server import serve

class FakeOBS:
    def __init__(self):
        self.active=False; self.paused=False; self.duration=0
        self.scene='Camera'; self.calls=[]; self.reject=False; self.drop=False
        self.auth_ok=False; self.client=None; self.drop_kind=None; self.event_on_get=False
    async def handle(self, ws):
        self.client=ws
        await ws.send(json.dumps({'op':0,'d':{'rpcVersion':1,'authentication':{'salt':'test-salt','challenge':'test-challenge'}}}))
        ident=json.loads(await ws.recv())
        self.auth_ok=ident['d']['authentication']==authentication('local-test','test-salt','test-challenge')
        if not self.auth_ok:
            await ws.close(code=4009); return
        await ws.send(json.dumps({'op':2,'d':{'negotiatedRpcVersion':1}}))
        async for raw in ws:
            d=json.loads(raw)['d']; kind=d['requestType']; self.calls.append(kind)
            out={}; ok=not self.reject
            if kind=='GetRecordStatus':out={'outputActive':self.active,'outputPaused':self.paused,'outputDuration':self.duration}
            elif kind=='StartRecord':self.active=True
            elif kind=='StopRecord':self.active=False;self.paused=False
            elif kind=='GetSceneList':out={'currentProgramSceneName':self.scene,'scenes':[{'sceneName':x} for x in ['Camera','Desk']]}
            elif kind=='SetCurrentProgramScene':self.scene=d['requestData']['sceneName']
            if self.event_on_get and kind=='GetRecordStatus':await self.event()
            if self.drop or kind==self.drop_kind:
                await ws.close();return
            await ws.send(json.dumps({'op':7,'d':{'requestId':d['requestId'],'requestStatus':{'result':ok,'code':100 if ok else 500},'responseData':out}}))
    async def event(self):
        await self.client.send(json.dumps({'op':5,'d':{'eventType':'RecordStateChanged','eventIntent':64,'eventData':{'outputActive':self.active}}}))

class Integration(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.fake=FakeOBS()
        self.server=await serve(self.fake.handle,'127.0.0.1',0)
        self.url='ws://127.0.0.1:'+str(self.server.sockets[0].getsockname()[1])
        self.obs=OBS(self.url,'local-test');await self.obs.open()
        self.c=Controller(self.obs,[])
    async def asyncTearDown(self):
        await self.obs.close();self.server.close();await self.server.wait_closed()
    async def test_handshake(self):self.assertTrue(self.fake.auth_ok)
    async def test_record_actual_and_duplicate(self):
        self.assertEqual(await self.c.snapshot(),'S 1 1 0 0 0\n')
        self.assertTrue(await self.c.event('E 1234 1 R'))
        self.assertFalse(await self.c.event('E 1234 1 R'))
        self.assertEqual(self.fake.calls.count('StartRecord'),1)
        self.fake.duration=125000
        self.assertEqual(await self.c.snapshot(),'S 1 1 1 0 125\n')
        self.c.last_command=-100
        await self.c.event('E 1234 2 R')
        self.assertEqual(self.fake.calls.count('StopRecord'),1)
    async def test_scene_cycle(self):
        await self.c.event('E 1234 1 N');self.assertEqual(self.fake.scene,'Desk')
    async def test_missing_scene(self):
        self.c.scenes=['Absent']
        with self.assertRaises(RuntimeError):await self.c.event('E 1234 1 N')
        self.assertNotIn('SetCurrentProgramScene',self.fake.calls)
    async def test_external_change_and_pause(self):
        self.fake.active=True;self.fake.paused=True;self.fake.duration=70100
        await self.fake.event();await asyncio.sleep(.01)
        self.assertGreater(self.obs.generation,0)
        self.assertEqual(await self.c.snapshot(),'S 1 1 1 1 70\n')
    async def test_bad_frames(self):
        for s in ['E nope 1 R','E ab -1 R','E ab 2 X','E ab 3 R extra','H 1 ab','E fffffffffff 1 R']:
            self.assertFalse(await self.c.event(s))
        self.assertEqual(self.fake.calls,[])
    async def test_reject_no_retry(self):
        self.fake.reject=True
        with self.assertRaises(RuntimeError):await self.c.event('E ab 1 R')
        self.fake.reject=False
        self.assertFalse(await self.c.event('E ab 1 R'))
        self.assertNotIn('StartRecord',self.fake.calls)
    async def test_disconnect_and_resync(self):
        self.fake.drop=True
        with self.assertRaises((ConnectionError,RuntimeError)):await self.c.event('E ab 1 R')
        self.assertFalse(self.obs.ready)
        self.fake.drop=False
        await self.obs.close();self.obs=OBS(self.url,'local-test');await self.obs.open()
        self.c.obs=self.obs
        self.assertEqual(await self.c.snapshot(),'S 1 1 0 0 0\n')
    async def test_cooldown(self):
        await self.c.event('E ab 1 R')
        self.assertFalse(await self.c.event('E ab 2 R'))
        self.assertEqual(self.fake.calls.count('StartRecord'),1)
    async def test_ambiguous_start_not_replayed(self):
        self.fake.drop_kind='StartRecord'
        with self.assertRaises(ConnectionError):await self.c.event('E ab 1 R')
        self.assertTrue(self.fake.active)
        await self.obs.close();self.obs=OBS(self.url,'local-test');await self.obs.open();self.c.obs=self.obs
        self.assertEqual(await self.c.snapshot(),'S 1 1 1 0 0\n')
        self.assertFalse(await self.c.event('E ab 1 R'))
        self.assertEqual(self.fake.calls.count('StartRecord'),1)
    async def test_event_invalidates_snapshot(self):
        self.fake.event_on_get=True
        with self.assertRaises(RuntimeError):await self.c.snapshot()

    async def test_wrong_password(self):
        o=OBS(self.url,'wrong')
        with self.assertRaises(Exception):await o.open()
        await o.close()

class FakePort:
    def __init__(self):
        self.incoming=queue.Queue();self.incoming.put(b'E cafe 99 R\n')
        self.outgoing=[];self.reset_count=0;self.closed=False;self.fail=False;self.dtr=False
    def reset_input_buffer(self):
        self.reset_count+=1
        while not self.incoming.empty():self.incoming.get_nowait()
    def read_until(self, terminator, limit):
        if self.fail:raise serial.SerialException('simulated USB unplug')
        try:return self.incoming.get(timeout=.02)
        except queue.Empty:return b''
    def write(self,data):
        if self.closed:raise serial.SerialException('closed')
        self.outgoing.append(data);return len(data)
    def close(self):self.closed=True

class USBTransport(unittest.IsolatedAsyncioTestCase):
    asyncSetUp = Integration.asyncSetUp
    asyncTearDown = Integration.asyncTearDown
    # Reuse independent OBS server but don't repeat inherited integration tests.
    async def test_serial_reconnect_and_queue_flush(self):
        ports=[]
        def factory(*args,**kwargs):
            port=FakePort();ports.append(port);return port
        async def wait(condition,timeout=4):
            end=asyncio.get_running_loop().time()+timeout
            while not condition():
                if asyncio.get_running_loop().time()>end:raise TimeoutError('transport test')
                await asyncio.sleep(.02)
        with patch('bridge.serial.Serial',factory), patch.dict(os.environ, {'OBS_PASSWORD':'local-test'}):
            task=asyncio.create_task(run(SimpleNamespace(obs_url=self.url,port='SIMULATED',scene=[])))
            try:
                await wait(lambda:ports and b'S 1 1 0 0 0\n' in ports[0].outgoing)
                self.assertEqual(ports[0].reset_count,1)
                self.assertNotIn('StartRecord',self.fake.calls)
                ports[0].incoming.put(b'E abcd 1 R\n')
                await wait(lambda:self.fake.active)
                await wait(lambda:b'S 1 1 1 0 0\n' in ports[0].outgoing)
                ports[0].fail=True
                await wait(lambda:len(ports)>1)
                await wait(lambda:b'S 1 1 1 0 0\n' in ports[1].outgoing)
                self.assertTrue(ports[0].closed)
                self.assertIn(b'S 1 0 0 0 0\n',ports[0].outgoing)
                self.assertEqual(self.fake.calls.count('StartRecord'),1)
                self.assertEqual(ports[1].reset_count,1)
            finally:
                task.cancel()
                try:await task
                except asyncio.CancelledError:pass
        self.assertTrue(all(p.closed for p in ports))

if __name__=='__main__':unittest.main(verbosity=2)
