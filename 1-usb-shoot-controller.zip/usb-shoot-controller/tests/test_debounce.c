#include <assert.h>
#include <stdio.h>
#include "../firmware/debounce.h"
int main(void){
 Button b={0};
 assert(!press(&b,true,0));assert(!press(&b,false,5));
 assert(!press(&b,true,10));assert(!press(&b,true,39));
 assert(press(&b,true,40));assert(!press(&b,true,500));
 assert(!press(&b,false,501));assert(!press(&b,true,505));
 assert(!press(&b,false,510));assert(!press(&b,false,540));
 assert(!b.stable);assert(!press(&b,true,550));assert(press(&b,true,580));
 b=(Button){.raw=true,.stable=true};assert(!press(&b,true,1000));
 puts("debounce: bounce, hold, release, second press, held-at-boot PASS");
}
