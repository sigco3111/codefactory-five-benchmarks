"""Validate UF2 against BIN and inspect the SDK USB config descriptor from ELF symbols."""
import json
import struct
import subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
folder=ROOT/'firmware'/'artifacts'
raw=(folder/'shoot_controller.uf2').read_bytes();binary=(folder/'shoot_controller.bin').read_bytes()
assert len(raw)%512==0
payload={};families=set();counts=set()
for i in range(0,len(raw),512):
 block=raw[i:i+512];m0,m1,flags,addr,size,no,total,family=struct.unpack_from('<8I',block)
 assert (m0,m1)==(0x0a324655,0x9e5d5157)
 assert struct.unpack_from('<I',block,508)[0]==0x0ab16f30
 assert size==256 and flags&0x2000 and family==0xe48bff56
 assert no not in payload
 payload[no]=(addr,block[32:32+size]);families.add(family);counts.add(total)
assert counts=={len(payload)}
reconstructed=b''
for no,(addr,data) in sorted(payload.items()):
 assert addr==0x10000000+256*no
 reconstructed+=data
assert reconstructed[:len(binary)]==binary
assert len(binary)<2*1024*1024
nm=ROOT/'tools'/'arm-gnu-toolchain-14.2.rel1-x86_64-arm-none-eabi'/'bin'/'arm-none-eabi-nm'
text=subprocess.check_output([str(nm),str(folder/'shoot_controller.elf')],text=True)
address=None
for line in text.splitlines():
 fields=line.split()
 if len(fields)==3 and fields[2]=='usbd_desc_cfg':address=int(fields[0],16)
assert address is not None
cfg=binary[address-0x10000000:address-0x10000000+9]
assert cfg[0:2]==bytes([9,2]) and cfg[8]==125
result=dict(uf2_blocks=len(payload),family_id=hex(next(iter(families))),flash_base='0x10000000',binary_bytes=len(binary),uf2_matches_bin=True,usb_descriptor=list(cfg),usb_requested_mA=cfg[8]*2)
(ROOT/'verification'/'binary-report.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
