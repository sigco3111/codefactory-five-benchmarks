"""Independent binary STL topology/volume checks, Python standard library only."""
import collections
import json
import struct
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
report={}
for path in sorted((ROOT/'enclosure').glob('*.stl')):
 data=path.read_bytes();count=struct.unpack_from('<I',data,80)[0]
 assert len(data)==84+50*count,(path,'binary STL byte count')
 edges=collections.Counter();adj=collections.defaultdict(list);volume=0;vertices=[]
 for i in range(count):
  values=struct.unpack_from('<12fH',data,84+50*i)
  points=[tuple(round(x,5) for x in values[k:k+3]) for k in [3,6,9]]
  vertices.extend(points);a,b,c=points
  volume+=(a[0]*(b[1]*c[2]-b[2]*c[1])+a[1]*(b[2]*c[0]-b[0]*c[2])+a[2]*(b[0]*c[1]-b[1]*c[0]))/6
  for k in range(3):
   edge=tuple(sorted((points[k],points[(k+1)%3])));edges[edge]+=1;adj[edge].append(i)
 neighbors=collections.defaultdict(set)
 for faces in adj.values():
  for a in faces:neighbors[a].update(faces)
 unvisited=set(range(count));components=0
 while unvisited:
  components+=1;stack=[unvisited.pop()]
  while stack:
   for j in neighbors[stack.pop()]:
    if j in unvisited:unvisited.remove(j);stack.append(j)
 bad=sum(1 for n in edges.values() if n!=2)
 report[path.name]=dict(triangles=count,nonmanifold_edges=bad,components=components,signed_volume_mm3=round(volume,3),bounds=[[min(p[d] for p in vertices) for d in range(3)],[max(p[d] for p in vertices) for d in range(3)]])
 assert bad==0 and components==1 and volume>0,report[path.name]
(ROOT/'verification'/'mesh-report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
