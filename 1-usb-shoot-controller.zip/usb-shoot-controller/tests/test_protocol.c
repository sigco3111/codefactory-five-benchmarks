#include <assert.h>
#include <stdio.h>
#include "../firmware/protocol.h"
int main(void){
 Status s={0};assert(parse_status("S 1 1 1 0 125",&s));assert(s.online&&s.active&&!s.paused&&s.seconds==125);
 assert(parse_status("S 1 1 1 1 3599999",&s));assert(s.paused);
 const char *bad[]={"","S","S 1 1 1 0","S 1 1 1 0 -1","S 1 1 1 0 3600000","S 2 1 1 0 1","S 1 2 1 0 1","S 1 1 0 1 1","S 1 1 1 0 1 extra","S 1 1 1 0 4294967296","S 1 1 1 0 99999999999999999999999999999999","S 1 1 1 0 +1","S 1 1 1 0 1x"};
 for(unsigned i=0;i<sizeof(bad)/sizeof(*bad);i++)assert(!parse_status(bad[i],&s));
 assert(status_link_fresh(true,1850,100));assert(!status_link_fresh(true,1851,100));assert(!status_link_fresh(false,101,100));
 puts("protocol: normal, paused, bounds, malformed, signed, overflow PASS (18 checks, including freshness boundary)");
}
