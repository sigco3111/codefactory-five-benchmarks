import functools
import http.server
import json
import threading
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
handler=functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(ROOT))
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),handler)
threading.Thread(target=server.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{server.server_port}'
errors=[];results={}
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
  page=browser.new_page(viewport={'width':1920,'height':1080},device_scale_factor=1)
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.goto(url+'/preview/');page.wait_for_function('window.previewState && previewState().parts>0 && document.querySelector("canvas").dataset.fontReady==="1"')
  page.screenshot(path=str(ROOT/'verification/preview-assembled.png'))
  page.locator('#rec').click();page.wait_for_timeout(1100)
  results['record']=page.evaluate('previewState()');assert results['record']['active']
  page.locator('#next').click();assert page.evaluate('previewState().sceneIndex')==1
  page.locator('#link').click();assert page.locator('#status').inner_text()=='LINK LOST'
  assert page.locator('#rec').is_disabled();assert 'on' not in page.locator('#led').get_attribute('class').split()
  results['disconnected']=page.evaluate('previewState()')
  page.locator('#link').click();assert page.locator('#status').inner_text()=='RECORDING'
  page.locator('#timeline').fill('8');page.locator('#timeline').dispatch_event('input');page.wait_for_timeout(200)
  page.screenshot(path=str(ROOT/'verification/preview-exploded.png'))
  page.locator('#play').click();page.wait_for_timeout(200);assert page.evaluate('previewState().t')>8
  page.goto(url+'/hardware/wiring.html');page.wait_for_function('document.querySelector("img").naturalWidth===1600');page.screenshot(path=str(ROOT/'verification/wiring.png'),full_page=True)
  page.set_viewport_size({'width':390,'height':844});page.goto(url+'/preview/');page.wait_for_function('previewState().parts>0 && document.querySelector("canvas").dataset.fontReady==="1"');page.screenshot(path=str(ROOT/'verification/preview-mobile.png'),full_page=True);assert page.evaluate('document.documentElement.scrollWidth')==390
  browser.close()
finally:server.shutdown()
results['browser_errors']=errors
(ROOT/'verification'/'preview-tests.json').write_text(json.dumps(results,indent=2))
assert not errors
print(json.dumps(results,indent=2))
