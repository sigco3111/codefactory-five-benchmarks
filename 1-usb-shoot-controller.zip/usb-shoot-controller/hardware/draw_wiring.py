"""Generate a legible connection diagram from the fixed pin mapping."""
from pathlib import Path
from html import escape
p=Path(__file__).resolve().parent
s=['<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1020" viewBox="0 0 1600 1020">', '<rect width="1600" height="1020" fill="#f6f4ee"/>']
def text(x,y,t,size=20,fill='#273a32'):
 s.append(f'<text x="{x}" y="{y}" fill="{fill}" font-family="DejaVu Sans, sans-serif" font-size="{size}">{escape(t)}</text>')
def line(points,color='#4b7568',w=3):
 s.append(f'<polyline points="{points}" stroke="{color}" stroke-width="{w}" fill="none"/>')
def box(x,y,w,h,c='#e2e8dc'):
 s.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="12" fill="{c}" stroke="#778779" stroke-width="2"/>')
text(65,65,'SHOOT 01 / USB WIRING',34)
text(65,104,'Original RP2040 Pico SC0915 + Waveshare Pico-OLED-1.3, default SPI',20)
text(65,139,'Connection diagram, not an electrical-CAD project. Physical pin numbers are in brackets.',17)
box(65,190,430,720);box(930,190,585,385)
text(92,233,'U1 · Raspberry Pi Pico',25);text(92,269,'Micro-USB B to computer',19)
text(958,233,'U2 · Pico-OLED-1.3',25);text(958,266,'Separate socket wiring, NOT stacked',18)
nets=[('VSYS [39]','VSYS [39]',315,'#cf5945'),('GND [38]','GND [38]',352,'#353b39'),('GP8 [11]','DC / GP8 [11]',389,'#a27734'),('GP9 [12]','CS / GP9 [12]',426,'#4779a7'),('GP10 [14]','CLK / GP10 [14]',463,'#438468'),('GP11 [15]','DIN / GP11 [15]',500,'#9b668e'),('GP12 [16]','RST / GP12 [16]',537,'#5a7d87')]
for a,b,y,c in nets:
 text(280,y+6,a,18);line(f'495,{y} 930,{y}',c);text(954,y+6,b,18)
text(65,960,'ALL GPIO SIGNALS 3.3 V. Do not connect 5 V to GPIO. Do not connect module socket 36.',20,'#ad4d39')
text(65,992,'Use hardware/wiring.csv and POWER.md. Insulate joints. Disconnect USB before changing any wire.',18)
# Buttons and LED include explicit ground paths, not symbolic floating returns.
for y,label,gp,pin in [(660,'SW1 / REC','GP2',4),(780,'SW2 / NEXT','GP3',5)]:
 text(275,y+5,f'{gp} [{pin}]',19);line(f'495,{y} 1065,{y}')
 s.append(f'<circle cx="1065" cy="{y}" r="5" fill="#344e40"/><circle cx="1165" cy="{y}" r="5" fill="#344e40"/>')
 line(f'1065,{y} 1155,{y-22}');line(f'1165,{y} 1395,{y} 1395,875 640,875')
 text(1055,y-25,label+' / NO',20);text(755,y-11,'internal pull-up',16)
text(280,880,'GND [3 / 18]',18);line('495,875 640,875','#353b39')
text(280,605,'GP14 [19]',18);line('495,600 640,600 640,610 690,610','#ce6849')
box(690,596,100,28,'#e9cf9e');text(701,616,'330 Ω',18)
line('790,610 1330,610','#ce6849');text(930,601,'D1 WP7113ID · A → K',17)
s.append('<path d="M 1330 598 L 1350 610 L 1330 622 Z M 1352 596 L 1352 624" fill="#d95842" stroke="#333" stroke-width="2"/>')
line('1352,610 1450,610 1450,875 1395,875','#353b39')
text(920,920,'SW1, SW2: Adafruit 1445 · normally open',18)
s.append('</svg>')
(p/'wiring.svg').write_text('\n'.join(s))
