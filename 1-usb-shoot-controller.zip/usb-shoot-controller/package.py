"""Create a source-only delivery archive, excluding downloaded build tools and caches."""
import hashlib
import json
import zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'usb-shoot-controller.zip'
files=[]
for p in ROOT.iterdir():
 if p.is_file() and (p.suffix in {'.md','.csv','.json'} or p.name in {'requirements-dev.txt','package.py'}):
  if p.name!='PACKAGE_MANIFEST.json':files.append(p)
for folder in ['host','enclosure','preview','hardware','tests']:
 for p in (ROOT/folder).rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:files.append(p)
for name in ['CMakeLists.txt','main.c','font.h','debounce.h','protocol.h','build.sh']:
 files.append(ROOT/'firmware'/name)
files.extend((ROOT/'firmware'/'artifacts').glob('*'))
for name in ['ORIGINAL_PROMPT.md','pico-mechanical-page7.jpg','oled-schematic.pdf','oled-dimensions.jpg','button-dimensions.jpg','led-datasheet.pdf']:
 files.append(ROOT/'reference'/name)
files.extend((ROOT/'reference'/'licenses').glob('*'))
for p in (ROOT/'verification').iterdir():
 if p.suffix in {'.png','.json'} or p.name in {'repro-build.log','host-tests.log','protocol.log','debounce.log','cad.log','binary.log','mesh.log','preview.log','host-help.txt','firmware-sha256.txt'}:
  files.append(p)
files=sorted(set(files))
manifest={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
mp=ROOT/'PACKAGE_MANIFEST.json';mp.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
files.append(mp)
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,'usb-shoot-controller/'+str(p.relative_to(ROOT)))
with zipfile.ZipFile(OUT) as z:
 assert z.testzip() is None
 for name,data in manifest.items():
  assert hashlib.sha256(z.read('usb-shoot-controller/'+name)).hexdigest()==data['sha256']
 assert not any('/tools/' in n or '/.git/' in n or '__pycache__' in n for n in z.namelist())
print(json.dumps({'file':str(OUT),'bytes':OUT.stat().st_size,'entries':len(files),'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest()},indent=2))
