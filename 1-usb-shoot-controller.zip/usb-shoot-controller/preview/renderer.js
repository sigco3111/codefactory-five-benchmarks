'use strict';
// Minimal offline WebGL renderer. Meshes are exported by enclosure/design.py.
function createCADRenderer(canvas){
 const gl=canvas.getContext('webgl',{antialias:true,preserveDrawingBuffer:true});
 if(!gl)throw Error('WebGL required for CAD preview');
 const vs=`attribute vec3 position;attribute vec3 color;varying vec3 rgb;uniform vec2 viewport;uniform float scale;
 void main(){float x=-0.08+(position.x-position.y-17.5)*.70710678*scale*2.0/viewport.x;
 float y=-.22+((position.x+position.y-102.5)*.40824829+position.z*.81649658)*scale*2.0/viewport.y;
 float z=(position.x+position.y-position.z)*.001;gl_Position=vec4(x,y,z,1.0);rgb=color;}`;
 const fs=`precision mediump float;varying vec3 rgb;void main(){gl_FragColor=vec4(rgb,1.0);}`;
 function shader(type,s){const sh=gl.createShader(type);gl.shaderSource(sh,s);gl.compileShader(sh);if(!gl.getShaderParameter(sh,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(sh));return sh}
 const program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,vs));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));gl.useProgram(program);
 const buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
 for(const [name,offset] of [['position',0],['color',12]]){const attr=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(attr);gl.vertexAttribPointer(attr,3,gl.FLOAT,false,24,offset)}
 const viewport=gl.getUniformLocation(program,'viewport'),scaleU=gl.getUniformLocation(program,'scale');
 const palette={base:'#435749',lid:'#ced3c7',pico:'#169c80',pico_parts:'#303935',pico_usb:'#a3aba5',oled:'#177da9',button_rec:'#333c34',button_scene:'#333c34',button_rec_cap:'#d34b39',button_scene_cap:'#d34b39',led:'#78372b',led_lens:'#78372b'};
 let font={};fetch('font.json').then(r=>r.json()).then(f=>{font=f;canvas.dataset.fontReady='1';canvas.dispatchEvent(new Event('cad-font-ready'))});
 return function(parts,t,active,linked,elapsed){
  const rect=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);gl.viewport(0,0,canvas.width,canvas.height);gl.clearColor(.929,.918,.890,1);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);gl.enable(gl.DEPTH_TEST);gl.depthFunc(gl.LEQUAL);gl.uniform2f(viewport,canvas.width,canvas.height);gl.uniform1f(scaleU,Math.min(canvas.width/310,canvas.height/220));
  const a=[],e=Math.max(0,Math.min(1,(t-2)/6)),explode=e*e*(3-2*e),dzFor=n=>n==='base'?0:(n==='pico'||n==='pico_parts'||n==='pico_usb'?22:58)*explode;
  function tri(pts,rgb,lit=true){let shade=1;if(lit){const u=pts[1].map((v,i)=>v-pts[0][i]),v=pts[2].map((v,i)=>v-pts[0][i]),n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]],len=Math.hypot(...n)||1;shade=.65+.35*Math.max(0,(-.4*n[0]-.5*n[1]+.77*n[2])/len)}for(const p of pts)a.push(...p,...rgb.map(v=>v*shade))}
  function quad(x,y,z,w,h,rgb){tri([[x,y,z],[x+w,y,z],[x+w,y+h,z]],rgb,false);tri([[x,y,z],[x+w,y+h,z],[x,y+h,z]],rgb,false)}
  for(const p of parts){if(p.name==='oled_header_keepout')continue;let hex=palette[p.name]||'#777777';if(p.name==='led_lens'&&active&&linked)hex='#ff4632';const rgb=hex.match(/[0-9a-f]{2}/gi).map(x=>parseInt(x,16)/255),dz=dzFor(p.name);for(const f of p.faces)tri(f.map(i=>{const v=p.vertices[i];return [v[0],v[1],v[2]+dz]}),rgb)}
  const z=42.32+58*explode;quad(68.29,20.15,z,29.42,14.7,[.04,.12,.15]);
  function txt(x,y,text,sz){for(const c of text){let rows=font[c]||[];rows.forEach((bits,j)=>{for(let i=0;i<6;i++)if(bits&(1<<i))quad(x+i*sz,y-j*sz,z+.02,sz*.85,sz*.85,linked?[.65,.95,.91]:[1,.7,.4])});x+=7*sz}}
  txt(70,32,linked?(active?'RECORDING':'READY'):'LINK LOST',.25);
  txt(70,26,linked?new Date(elapsed*1000).toISOString().slice(11,19):'--:--:--',.25);
  gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(a),gl.DYNAMIC_DRAW);gl.drawArrays(gl.TRIANGLES,0,a.length/6);
 };
}
