#ifndef DEBOUNCE_H
#define DEBOUNCE_H
#include <stdbool.h>
#include <stdint.h>
typedef struct {bool raw,stable;uint64_t changed;} Button;
static inline bool press(Button*b,bool down,uint64_t now){
 if(down!=b->raw){b->raw=down;b->changed=now;}
 if(b->stable!=b->raw&&now-b->changed>=30){b->stable=b->raw;return b->stable;}
 return false;
}
#endif
