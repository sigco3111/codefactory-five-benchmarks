#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "pico/stdlib.h"
#include "pico/stdio_usb.h"
#include "hardware/spi.h"
#include "pico/rand.h"
#include "font.h"
#include "protocol.h"
#include "tusb.h"
// Exact target: original RP2040 Raspberry Pi Pico, not Pico W/2.
#define REC_PIN 2
#define NEXT_PIN 3
#define LED_PIN 14
#define DC 8
#define CS 9
#define CLK 10
#define MOSI 11
#define RST 12
static uint8_t fb[1024];
static void cmd(uint8_t b){gpio_put(CS,1);gpio_put(DC,0);gpio_put(CS,0);spi_write_blocking(spi1,&b,1);gpio_put(CS,1);}
static void display_init(void){
 spi_init(spi1,2000000);gpio_set_function(CLK,GPIO_FUNC_SPI);gpio_set_function(MOSI,GPIO_FUNC_SPI);
 int pins[]={DC,CS,RST};for(unsigned i=0;i<3;i++){gpio_init(pins[i]);gpio_set_dir(pins[i],GPIO_OUT);gpio_put(pins[i],1);}
 gpio_put(RST,0);sleep_ms(10);gpio_put(RST,1);sleep_ms(10);
 // SH1107 sequence and row mapping follow Waveshare Pico-OLED-1.3 SPI demo.
 const uint8_t init[]={0xae,0,0x10,0xb0,0xdc,0,0x81,0x6f,0x21,0xa0,0xc0,0xa4,0xa6,0xa8,0x3f,0xd3,0x60,0xd5,0x41,0xd9,0x22,0xdb,0x35,0xad,0x8a,0xaf};
 for(unsigned i=0;i<sizeof(init);i++)cmd(init[i]);
}
static void show(void){cmd(0xb0);for(int y=0;y<64;y++){int col=63-y;cmd(col&15);cmd(0x10|(col>>4));gpio_put(DC,1);gpio_put(CS,0);spi_write_blocking(spi1,fb+y*16,16);gpio_put(CS,1);}}
static void text(int x,int y,const char*s){for(;*s && x<121;s++,x+=7){unsigned c=(unsigned char)*s;if(c<32||c>126)c='?';for(int j=0;j<10;j++)for(int i=0;i<6;i++)if(font[c-32][j]&(1<<i)){int px=x+i,py=y+j;if(px>=0&&px<128&&py>=0&&py<64)fb[py*16+px/8]|=0x80>>(px%8);}}}
#include "debounce.h"
int main(void){
 stdio_init_all();while(!tud_mounted())sleep_ms(10);display_init();gpio_init(LED_PIN);gpio_set_dir(LED_PIN,GPIO_OUT);gpio_set_drive_strength(LED_PIN,GPIO_DRIVE_STRENGTH_8MA);gpio_put(LED_PIN,0);
 int pins[]={REC_PIN,NEXT_PIN};Button buttons[2]={0};for(int i=0;i<2;i++){gpio_init(pins[i]);gpio_set_dir(pins[i],GPIO_IN);gpio_pull_up(pins[i]);buttons[i].raw=buttons[i].stable=!gpio_get(pins[i]);}
 // Boot id is a correlation token, not a cryptographic credential.
 uint32_t boot=get_rand_32();
 uint32_t seq=0,seconds=0;bool online=false,active=false,paused=false;uint64_t last=0,draw=0,cool=0,hello=0;
 char line[100];size_t n=0;bool dropping=false;
 while(true){uint64_t now=to_ms_since_boot(get_absolute_time());
  for(int k=0;k<64;k++){int c=getchar_timeout_us(0);if(c==PICO_ERROR_TIMEOUT)break;if(c=='\n'){if(!dropping){line[n]=0;Status st;if(parse_status(line,&st)){online=st.online;active=st.active;paused=st.paused;seconds=st.seconds;last=now;}}n=0;dropping=false;}else if(c!='\r'){if(n<sizeof(line)-1&&!dropping)line[n++]=(char)c;else dropping=true;}}
  if(!status_link_fresh(stdio_usb_connected(),now,last))online=false;
  gpio_put(LED_PIN,online&&active);
  if(stdio_usb_connected()&&now-hello>=1000){printf("H 1 %08" PRIx32 "\n",boot);hello=now;}
  for(int i=0;i<2;i++){if(press(&buttons[i],!gpio_get(pins[i]),now)&&online&&now-cool>=500){printf("E %08" PRIx32 " %" PRIu32 " %c\n",boot,++seq,i?'N':'R');cool=now;}}
  if(now-draw>=200){memset(fb,0,sizeof(fb));text(0,0,"SHOOT / USB");text(0,15,online?(active?(paused?"PAUSED":"RECORDING"):"READY"):"LINK LOST");char t[24];if(online)snprintf(t,sizeof(t),"%02u:%02u:%02u",(unsigned)(seconds/3600),(unsigned)((seconds/60)%60),(unsigned)(seconds%60));else snprintf(t,sizeof(t),"--:--:--");text(0,30,t);text(0,48,"REC     SCENE >");show();draw=now;}
  sleep_ms(1);
 }
}
