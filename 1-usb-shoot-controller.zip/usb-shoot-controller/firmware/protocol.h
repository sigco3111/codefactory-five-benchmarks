#ifndef SHOOT_PROTOCOL_H
#define SHOOT_PROTOCOL_H
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <errno.h>
typedef struct {bool online,active,paused;uint32_t seconds;} Status;
static inline bool parse_status(const char *line,Status *out){
 if(line[0]!='S'||line[1]!=' ')return false;
 const char *p=line+2;unsigned long values[5];
 for(int i=0;i<5;i++){
  while(*p==' ')p++;
  if(*p<'0'||*p>'9')return false;
  errno=0;char *end;values[i]=strtoul(p,&end,10);
  if(errno==ERANGE||end==p)return false;
  p=end;
  if(i<4&&*p!=' ')return false;
 }
 while(*p==' ')p++;
 if(*p||values[0]!=1||values[1]>1||values[2]>1||values[3]>1||values[4]>3599999||values[3]>values[2])return false;
 *out=(Status){.online=values[1],.active=values[2],.paused=values[3],.seconds=(uint32_t)values[4]};
 return true;
}
static inline bool status_link_fresh(bool usb_connected,uint64_t now,uint64_t last){return usb_connected&&now-last<=1750;}
#endif
