#!/usr/bin/env bash
# Linux x86_64 reference build. Writes only below this project directory.
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
mkdir -p tools verification firmware/artifacts
SDK_COMMIT=bddd20f928ce76142793bef434d4f75f4af6e433
TINYUSB_COMMIT=86ad6e56c1700e85f1c5678607a762cfe3aa2f47
PICOTOOL_COMMIT=91c7f8525a397e0411fd3aa129361fbc30f2ea3b
if [ ! -d tools/pico-sdk/.git ]; then
  git clone --branch 2.1.1 --depth 1 https://github.com/raspberrypi/pico-sdk.git tools/pico-sdk
fi
test "$(git -C tools/pico-sdk rev-parse HEAD)" = "$SDK_COMMIT"
git -C tools/pico-sdk submodule update --init lib/tinyusb
test "$(git -C tools/pico-sdk/lib/tinyusb rev-parse HEAD)" = "$TINYUSB_COMMIT"
if [ ! -d tools/arm-gnu-toolchain-14.2.rel1-x86_64-arm-none-eabi ]; then
  if [ ! -f tools/arm.tar.xz ]; then
    curl -L --fail https://developer.arm.com/-/media/Files/downloads/gnu/14.2.rel1/binrel/arm-gnu-toolchain-14.2.rel1-x86_64-arm-none-eabi.tar.xz -o tools/arm.tar.xz
  fi
  printf '%s\n' '62a63b981fe391a9cbad7ef51b17e49aeaa3e7b0d029b36ca1e9c3b2a9b78823  tools/arm.tar.xz' | sha256sum -c -
  tar -xf tools/arm.tar.xz -C tools
fi
if [ ! -d tools/picotool/.git ]; then
  git clone https://github.com/raspberrypi/picotool.git tools/picotool
  git -C tools/picotool checkout --detach "$PICOTOOL_COMMIT"
fi
test "$(git -C tools/picotool rev-parse HEAD)" = "$PICOTOOL_COMMIT"
# Build pinned picotool natively rather than allowing SDK 2.1.1 to fetch develop.
cmake -S tools/picotool -B tools/picotool-build \
  -DPICO_SDK_PATH="$ROOT/tools/pico-sdk" -DPICOTOOL_NO_LIBUSB=1 \
  -DPICOTOOL_FLAT_INSTALL=1 -DCMAKE_INSTALL_PREFIX="$ROOT/tools/picotool-install"
cmake --build tools/picotool-build --parallel 4
cmake --install tools/picotool-build
export PATH="$ROOT/tools/arm-gnu-toolchain-14.2.rel1-x86_64-arm-none-eabi/bin:$PATH"
arm-none-eabi-gcc --version
cmake -S firmware -B firmware/repro-build -DPICO_BOARD=pico -DPICO_PLATFORM=rp2040 \
  -DCMAKE_BUILD_TYPE=Release -DPICO_SDK_PATH="$ROOT/tools/pico-sdk" \
  -Dpicotool_DIR="$ROOT/tools/picotool-install/picotool"
cmake --build firmware/repro-build --parallel 4
cp firmware/repro-build/shoot_controller.uf2 firmware/repro-build/shoot_controller.bin firmware/repro-build/shoot_controller.elf firmware/artifacts/
arm-none-eabi-size firmware/artifacts/shoot_controller.elf
sha256sum firmware/artifacts/* > verification/firmware-sha256.txt
