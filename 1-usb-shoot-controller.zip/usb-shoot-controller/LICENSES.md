# 사용한 오픈소스와 문서

원본 설계/프로그램에 대한 별도 라이선스 선택은 사용자가 정한다. 이 파일은 포함된 제3자 자료의 출처/고지를 보존하기 위한 것이다. 아래 라이선스가 이 프로젝트 전체에 자동 적용된다는 뜻은 아니다.

- Raspberry Pi Pico SDK 2.1.1, BSD-3-Clause 계열 고지: `reference/licenses/Pico-SDK.txt`. 원본 https://github.com/raspberrypi/pico-sdk . SDK 전체 소스는 ZIP에 넣지 않았으며 빌드 스크립트가 고정 커밋을 받는다.
- TinyUSB, MIT: `reference/licenses/TinyUSB.txt`. 펌웨어에 링크된다.
- picotool, BSD-3-Clause: `reference/licenses/picotool.txt`. 로컬 빌드 보조 도구이며 실행 파일/소스는 최종 ZIP에 넣지 않았다.
- DejaVu Sans Mono에서 생성한 6×10 비트맵 글꼴, Bitstream/DejaVu 고지: `reference/licenses/DejaVu.txt`. 펌웨어 `font.h`와 미리보기 `font.json`에 사용했다.
- Noto Sans KR, SIL Open Font License 1.1: `preview/fonts/OFL.txt`. 미리보기 한글 표시용. 원본 https://github.com/google/fonts/tree/main/ofl/notosanskr . 글꼴 파일은 수정하지 않았다.
- SH1107 초기화 명령과 버퍼 매핑은 Waveshare 공식 Pico-OLED-1.3 예제를 참고했다. 원문 출처는 SOURCES.md. 전체 예제를 프로젝트 코드로 재배포하지 않는다.
- 공식 PDF/치수 이미지가 reference에 포함된다. 각 제조사의 문서이며 설계 검토 근거로 보존했다. 권리 표시는 원본 그대로다.

호스트/개발 의존성의 라이선스는 설치한 각 패키지의 배포 고지를 따른다. 패키지/툴체인/브라우저 바이너리는 최종 ZIP에 포함하지 않는다.
